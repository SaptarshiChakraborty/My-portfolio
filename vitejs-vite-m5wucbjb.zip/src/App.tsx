import React from 'react';
import './App.css';

function App() {
  return (
    <div className="bg-white dark:bg-[#1f1f1f] min-h-screen font-sans">
      {/* NAVBAR */}
      <nav className="flex justify-between items-center px-10 py-6 shadow bg-white dark:bg-[#1f1f1f] sticky top-0 z-50">
        <div className="text-xl font-bold text-gray-800 dark:text-white">
          Saptarshi
        </div>
        <ul className="flex space-x-6 text-gray-700 dark:text-gray-200 font-medium">
          <li>
            <a href="#home" className="hover:text-blue-600">
              Home
            </a>
          </li>
          <li>
            <a href="#about" className="hover:text-blue-600">
              About
            </a>
          </li>
          <li>
            <a href="#skills" className="hover:text-blue-600">
              Skills
            </a>
          </li>
          <li>
            <a href="#works" className="hover:text-blue-600">
              Works
            </a>
          </li>
          <li>
            <a href="#contact" className="hover:text-blue-600">
              Contact
            </a>
          </li>
        </ul>
      </nav>

      {/* HERO SECTION */}
      <section
        id="home"
        className="flex flex-col md:flex-row items-center justify-between px-10 py-20"
      >
        <div>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-4">
            Hi, I’m <span className="text-blue-600">Saptarshi</span>
            <br />
            Inside Sales Manager
          </h1>
          <a href="#contact">
            <button className="mt-4 px-6 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition">
              Contact
            </button>
          </a>
        </div>
        <div className="mt-10 md:mt-0">
          <img
            src="https://i.ibb.co/QdJwgmp/avatar.png"
            alt="avatar"
            className="w-64 h-64 object-cover rounded-full bg-blue-600 p-2"
          />
        </div>
      </section>

      {/* ABOUT SECTION */}
      <section id="about" className="mt-24 px-10">
        <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-white mb-6">
          About Me
        </h2>
        <p className="text-lg max-w-3xl mx-auto text-center text-gray-600 dark:text-gray-300">
          I’m a passionate Inside Sales Manager with experience in generating
          leads, closing deals, and creating strategic sales funnels that scale
          across B2B industries.
        </p>
      </section>

      {/* SKILLS SECTION */}
      <section id="skills" className="mt-24 px-10">
        <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-white mb-6">
          Skills
        </h2>
        <div className="flex flex-wrap justify-center gap-6 text-center">
          {[
            'Cold Calling',
            'Email Marketing',
            'Lead Generation',
            'CRM Tools',
            'Sales Enablement',
            'Team Management',
          ].map((skill) => (
            <div
              key={skill}
              className="bg-white dark:bg-[#2a2a2a] px-6 py-4 rounded-xl shadow-md w-40"
            >
              <p className="font-semibold text-gray-800 dark:text-gray-100">
                {skill}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* WORKS SECTION */}
      <section id="works" className="mt-24 px-10">
        <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-white mb-6">
          My Projects
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-white dark:bg-[#2a2a2a] p-4 rounded-xl shadow hover:shadow-xl transition">
            <h3 className="text-xl font-bold text-gray-800 dark:text-white">
              Sales Funnel System
            </h3>
            <p className="text-gray-600 dark:text-gray-300 mt-2">
              Custom sales funnel built using CRM tools for better lead
              conversion.
            </p>
            <a href="#contact" className="text-blue-600 mt-3 inline-block">
              Know More
            </a>
          </div>
        </div>
      </section>

      {/* CONTACT SECTION */}
      <section id="contact" className="mt-24 mb-20 px-10">
        <h2 className="text-3xl font-bold text-center text-gray-800 dark:text-white mb-6">
          Contact Me
        </h2>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            alert('Form submitted successfully! (Demo only)');
          }}
          className="max-w-xl mx-auto flex flex-col gap-4 bg-white dark:bg-[#2a2a2a] p-8 rounded-xl shadow"
        >
          <input
            type="text"
            placeholder="Your Name"
            className="p-3 rounded-md bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white"
            required
          />
          <input
            type="email"
            placeholder="Your Email"
            className="p-3 rounded-md bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white"
            required
          />
          <textarea
            placeholder="Your Message"
            rows="4"
            className="p-3 rounded-md bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white"
            required
          />
          <button
            type="submit"
            className="bg-blue-600 text-white py-2 rounded-md hover:bg-blue-700 transition"
          >
            Send Message
          </button>
        </form>
      </section>
    </div>
  );
}

export default App;
